import bpy
import bmesh

from .addon_checks import requirements_checks

# Main

class ZGSWTOR_OT_remove_doubles(bpy.types.Operator):
    bl_idname = "zgswtor.remove_doubles"
    bl_label = "ZG Remove Doubles"
    bl_description = "Removes objects' double vertices (does a Merge by Distance\n using a threshold of 0.0000001), and applies\nan 'Use Sharp Edge From Normals'.\n\nIt processes each selected object individually.\n\nIf applied to SWTOR objects, this tool will look for the mesh scale\nthey were imported with, to adjust the threshold accordingly"
    bl_options = {'REGISTER', "UNDO"}


    # Check that there is a selection of objects and that we are in Object mode
    # (greys-out the UI button otherwise) 
    @classmethod
    def poll(cls,context):
        context = bpy.context
        if context.area.type == 'VIEW_3D':
            if context.mode == 'EDIT_MESH':
                return False
            elif context.mode == 'OBJECT':
                for obj in bpy.data.objects:
                    if obj.type == "MESH":
                            return True
        return False
    

    use_selection_only : bpy.props.BoolProperty(
        name="Apply To Selected Objects Only",
        description="Apply to selected objects only.",
        default=True,
        options={'HIDDEN'},
    )

    def execute(self, context):

        context.window.cursor_set("WAIT")  # Show wait cursor icon

        # Checking if we must handle SWTOR objects' custom properties about their meshes' scales
        use_gr2_scale_custom_prop = context.preferences.addons["zg_swtor_tools_nx"].preferences.use_gr2_scale_custom_prop

        # Checking if we have a SWTOR IO Tools add-on with scaling parameters
        checks = requirements_checks()
        if checks["swIOt"] == True:
            if context.preferences.addons["swtor_io_tools"].preferences.gr2_scale_object:
                gr2_scale = context.preferences.addons["swtor_io_tools"].preferences.gr2_scale_factor
            else:
                gr2_scale = 1.0
        else:
            gr2_scale = 1.0
        
        
        print("---------------------")
        print("MERGE DOUBLE VERTICES")
        print("---------------------")
        print()

        # After some research, Crunch (AKA UnconventionalError) has changed the code to become
        # bpy.ops-based instead of BMESH based, as that allows for using a type of normals processing
        # that better preserves sharp edges with just an additional parameter.
        vert_count_report = 0

        if self.use_selection_only == True:
            mesh_objects_to_process = [obj for obj in bpy.context.selected_objects if obj.type == "MESH"]
            if not mesh_objects_to_process:
                self.report({"WARNING"}, "No mesh objects were selected.")
                return {"CANCELLED"}
        else:
            mesh_objects_to_process = [obj for obj in bpy.data.objects if obj.type == "MESH"]
                    
        objs_amount = len(mesh_objects_to_process)
        objs_count = 0
        
        # To avoid reprocessing meshes from instanced objects,
        # we'll keep a list of those to check against.
        instanced_meshes = []

        # Deselect all objects first to be able to re-select them one by one.
        bpy.ops.object.select_all(action='DESELECT')
        
        for obj in mesh_objects_to_process:
            objs_count += 1
            if obj.data.name not in instanced_meshes:
                print(f"{objs_count*100/objs_amount:.0f} %")
                print(obj.name)

                # As the object can have its own scaling plus scalings
                # inherited from parent objects, we get its accumulated
                # scaling.
                # Just in case there are non-uniform scalings, we are
                # using the highest one among the axes.
                obj_world_scale =  max(obj.matrix_world.to_scale())                
                # Option 2: Use the average scale component (balanced option)
                # global_scale = obj.matrix_world.to_scale()
                # obj_world_scale = sum(global_scale) / len(global_scale)
                
                
                # There is also the mesh-level scaling that the .gr2 importer
                # or the Quickscaler's "Apply" tool could have imparted on the
                # object, also annotating it with a custom property.
                if "gr2_scale" in obj and use_gr2_scale_custom_prop:
                    gr2_scale = obj["gr2_scale"]


                obj_initial_vert_count = len(obj.data.vertices)
                
                # Set object as the active one.
                context.view_layer.objects.active = obj
                
                # Switch object to Edit Mode.
                bpy.ops.object.editmode_toggle()
                
                # Select all vertices.
                bpy.ops.mesh.select_all(action='SELECT')
                
                # Actual merge doubles operation:
                # We multiply the eyeballed threshold for 1:1 object scale by
                # both the applied mesh scale and the accumulated object-level scale.
                bpy.ops.mesh.remove_doubles(threshold=1e-06 * gr2_scale * obj_world_scale, use_sharp_edge_from_normals=True)
                
                # Switch back to Object Mode.
                bpy.ops.object.editmode_toggle()
                
                # Add object's mesh ID to the list of already processed meshes
                instanced_meshes.append(obj.data.name)
                
                # Deselect
                context.view_layer.objects.active = None
                vert_count_report += len(obj.data.vertices) - obj_initial_vert_count
                print()

        print("\nDONE!")
        
        for obj in mesh_objects_to_process:
           obj.select_set(True)
        
        self.report({'INFO'}, str(-vert_count_report) + " Vertices merged.")

        bpy.context.window.cursor_set("DEFAULT")  # Show normal cursor icon
        return {"FINISHED"}


# UI is set in addon_ui.py


# Registrations

def register():
    bpy.utils.register_class(ZGSWTOR_OT_remove_doubles)

def unregister():
    bpy.utils.unregister_class(ZGSWTOR_OT_remove_doubles)

if __name__ == "__main__":
    register()